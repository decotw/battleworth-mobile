
/* Battleworth Mobile shell — visual/input wrapper only. */
(() => {
  'use strict';
  const root = document.documentElement;
  const body = document.body;

  function refreshViewportUnit(){
    root.style.setProperty('--bw-vh', `${window.innerHeight * 0.01}px`);
  }

  function requestLandscape(){
    try {
      if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('landscape').catch(() => {});
      }
    } catch (_) {}
  }

  body.classList.add('bw-native-mobile');
  refreshViewportUnit();

  document.addEventListener('contextmenu', e => {
    if (!e.target.closest('input,textarea,[contenteditable="true"]')) e.preventDefault();
  }, { passive:false });
  document.addEventListener('dragstart', e => e.preventDefault(), { passive:false });
  document.addEventListener('dblclick', e => {
    if (!e.target.closest('input,textarea,[contenteditable="true"]')) e.preventDefault();
  }, { passive:false });

  let requested = false;
  const firstGesture = () => {
    if (!requested) {
      requested = true;
      requestLandscape();
    }
  };
  document.addEventListener('pointerdown', firstGesture, { once:true, passive:true });
  document.addEventListener('touchstart', firstGesture, { once:true, passive:true });

  window.addEventListener('resize', refreshViewportUnit, { passive:true });
  window.addEventListener('orientationchange', refreshViewportUnit, { passive:true });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      refreshViewportUnit();
      requestLandscape();
    }
  });
})();
