#!/usr/bin/env python3
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
ANDROID = ROOT / "android"
APP_ID = "com.wpinformatica.battleworth"
JAVA_DIR = ANDROID / "app/src/main/java/com/wpinformatica/battleworth"
MANIFEST = ANDROID / "app/src/main/AndroidManifest.xml"

if not ANDROID.exists():
    raise SystemExit("android/ não existe. Rode primeiro: npx cap add android")

JAVA_DIR.mkdir(parents=True, exist_ok=True)

main_activity = """package com.wpinformatica.battleworth;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.WindowManager;

import androidx.activity.EdgeToEdge;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        EdgeToEdge.enable(this);
        applyImmersiveMode();
    }

    @Override
    public void onResume() {
        super.onResume();
        applyImmersiveMode();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    private void applyImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );
    }
}
"""
(JAVA_DIR / "MainActivity.java").write_text(main_activity, encoding="utf-8")

java_root = ANDROID / "app/src/main/java"
for p in java_root.rglob("MainActivity.java"):
    if p.resolve() != (JAVA_DIR / "MainActivity.java").resolve():
        txt = p.read_text(encoding="utf-8", errors="ignore")
        if "extends BridgeActivity" in txt:
            p.unlink()

ET.register_namespace("android", "http://schemas.android.com/apk/res/android")
tree = ET.parse(MANIFEST)
root = tree.getroot()
ns = "{http://schemas.android.com/apk/res/android}"
app = root.find("application")
activity = None
for a in app.findall("activity"):
    name = a.get(ns + "name", "")
    if name.endswith(".MainActivity") or name == ".MainActivity":
        activity = a
        break
if activity is None:
    raise SystemExit("MainActivity não encontrada.")

activity.set(ns + "name", ".MainActivity")
activity.set(ns + "screenOrientation", "sensorLandscape")
activity.set(ns + "exported", "true")
activity.set(ns + "launchMode", "singleTask")
activity.set(ns + "configChanges",
             "orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode|navigation|density")
tree.write(MANIFEST, encoding="utf-8", xml_declaration=True)

gradle = ANDROID / "app/build.gradle"
if gradle.exists():
    s = gradle.read_text(encoding="utf-8")
    s = re.sub(r'namespace\s*=\s*"[^"]+"', f'namespace = "{APP_ID}"', s)
    s = re.sub(r'applicationId\s+"[^"]+"', f'applicationId "{APP_ID}"', s)
    gradle.write_text(s, encoding="utf-8")
